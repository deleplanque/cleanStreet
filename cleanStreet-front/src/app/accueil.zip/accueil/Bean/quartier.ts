export class Quartier {
  constructor(
    public id: number,
    public nom: String
  ) {   }
}
