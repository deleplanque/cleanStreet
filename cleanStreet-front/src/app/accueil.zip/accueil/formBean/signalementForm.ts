
export class SignalementForm {

  constructor(
    public description: string,
    public indiceDeProprete: number,
    public image: String,
  ) {  }

}
